input_dir <- "Raw_data"
output_dir <- "Results"
if(!dir.exists(output_dir)){
  dir.create(output_dir)
}

files_to_process <- c("DEGs_Data_1.csv", "DEGs_Data_2.csv") 
results_list = list()
classify_gene <- function(logFC, padj){
  ifelse(padj <0.05 & logFC < -1, "Downregulated",
         ifelse(padj < 0.05 & logFC > 1, "Unregulated", "Not significant"))
}

for(files in files_to_process){
  cat("\nProcessing :", files, "\n")
  file_path <- file.path(input_dir, files)
  data <- read.csv(file_path, header = TRUE)
  cat("Files imported !, checking for missing values..... \n")
  
  if("padj" %in% names(data)){
    missing_count <- sum(is.na(data$padj))
    cat("Missing values in Padj column :", missing_count, "\n")
    data$padj[is.na(data$padj)] <- mean(data$padj, na.rm = TRUE)
  }
  
  if("logFC" %in% names(data)){
    missing_count <- sum(is.na(data$logFC))
    cat("Missing values in logFC column :", missing_count, "\n")
    data$logFC[is.na(data$logFC)] <- mean(data$logFC, na.rm = TRUE)
  }
  
  data$Gene_Class <- classify_gene(data$logFC, data$padj)
  cat("Gene has been classified successfully! \n")
  results_list[[files]] <- data
  
  output_file_path <- file.path(output_dir, paste0("Classification "))
  write.csv(data, output_file_path, row.names = FALSE)
  cat("Results saved to: ", output_file_path, "\n")
                                
  gene_counts <- table(data$Gene_class)
  cat("Summary counts for", files, ":\n")
  print(gene_counts)
}

result_1 = results_list[[1]]
result_2 = results_list[[2]]

save.image(file = "ObisesanAdedayo_2_Assignment.RData")
